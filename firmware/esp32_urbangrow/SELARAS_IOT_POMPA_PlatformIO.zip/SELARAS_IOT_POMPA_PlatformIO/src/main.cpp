#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

#define RELAY_PIN 14

#define LCD_SDA 21
#define LCD_SCL 22

// Relay aktif LOW
#define RELAY_ON LOW

// Coba alamat LCD 0x27
LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {

  // Relay
  pinMode(RELAY_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, RELAY_ON);

  // I2C LCD
  Wire.begin(LCD_SDA, LCD_SCL);

  lcd.init();
  lcd.backlight();

  lcd.clear();

  lcd.setCursor(0, 0);
  lcd.print("SELARAS IoT");

  lcd.setCursor(0, 1);
  lcd.print("POMPA: ON");
}

void loop() {

  // Pompa tetap ON
  digitalWrite(RELAY_PIN, RELAY_ON);

}